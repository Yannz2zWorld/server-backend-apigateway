module.exports = {

  //======= Setting Telegram =======//
  botToken: "8189301842:AAF0lyuqVFy0i2WkAGf942a4tWR5yT_NtAE",
  ownerId: 6877102514,
  ownerName: "Byyverse",
  ownerWa: "6285934931031",
  ownerUser: "@Byyverse",
  botName: "AUTO ORDER BYYVERSE",
  startPhoto: "https://files.catbox.moe/1c0axw.jpg",
  photosucces: "https://files.catbox.moe/1c0axw.jpg", // foto send channel
  buyvpsfoto: "https://files.catbox.moe/f8pn50.jpg", // foto send channel
  buydofoto: "https://files.catbox.moe/m3dmg1.jpg", // foto send channel
  buyvpsinfofoto: "https://files.catbox.moe/hdwgxw.jpg", // foto send channel Buy Vps
  startAudio: "https://files.catbox.moe/kc5bwz.mp3",
  startAudioCaption: "🛍 BYYVERSE AUTO ORDER 🛒",
  testimoniChannel: "@byyverseproduk",
  ChannelOwner: "https://t.me/byyverseproduk",
  GroupOwner: "https://t.me/byyverseproduk",
  resvps: "Hubungi Admin",
  resellerpanelLegal: "https://t.me/+qndm_Q2jYnBmMWNl",
  buyubot: "Hubungi Admin",
  rulesdo: "https://telegra.ph/DESKRIPSI-BUY-AKUN-DIGITAL-OCEAN-01-09",
  succesdepootp: "https://o.uguu.se/QFGEwhLA.jpg",
  succestrxotp: "https://o.uguu.se/WaUEuWgr.jpg",
  resellerPanelbiasa: "Hubungi Admin",

  //======= Setting Pakasir =======//
  pakasir: {
    apikey: "8MCy5me4LtUQkxi0D0yw0P55G59NSQqs", // Ganti dengan API Key Pakasir Anda
    project: "ripzz",   // Ganti dengan Project Slug Pakasir Anda
    mode: "api" // "api" atau "url" (Disarankan API untuk bot)
  },

  //======= Setting Penarikan (WD) =======//
  wd_balance: {
    bank_code: "DANA", // DANA, BCA, BRI, dll
    destination_number: ",0895337463785",
    destination_name: "blm gw isi nma",
  },
  
  // --- Suntik Sosmed Setting ( FayuPedia )
    smm: {
        apiId: '6827', 
        apiKey: 'yargle-ys7ibx-bn5nje-w7llhi-nz6aee', 
        baseUrl: 'https://fayupedia.id/api' 
    },

  // --- Nokos Setting 
  RUMAHOTP: "rk-dev-GNqjRdA0QP85CzMixOjJLKsninJZ0LcL",
  UNTUNG_NOKOS: 1000,
  UNTUNG_DEPOSIT: 760,

  /// START WINGS
  tokeninstall: "revan",
  bash: "bash <(curl https://raw.githubusercontent.com/zerodevxc/revan/refs/heads/main/install.sh)",

  menuEffects: [
    "5104841245755180586",
    "5107584321108051014",
    "5159385139981059251",
    "5046509860389126442"
  ],

  premiumEffects: [
    "5103512349875603456",
    "5109987654321009876",
    "5198877665544332211"
  ],

  //======= Manual QRIS =======//
  manualQrisPhoto: "https://files.catbox.moe/0jxi4e.jpg",

  //======= Setting VPS =======//
  ApiDO1: "", // ganti api do lu
  hargaVPS: {
    low: {
      "2c2": 5000,
      "4c2": 5500,
      "8c4": 6000,
      "16c4": 6000,
      "16c8": 7000
    },
    medium: {
      "2c2": 9000,
      "4c2": 9500,
      "8c4": 10000,
      "16c4": 11000,
      "16c8": 12000
    },
    high: {
      "2c2": 10000,
      "4c2": 11000,
      "8c4": 13000,
      "16c4": 14000,
      "16c8": 15000
    }
  },

  //======= GEMINI SETTING =======//
  USER_LIMIT: 3,
  GEMINI_API_KEY: "AIzaSyCSkRqdEvLLS8pCel_4Ir39-k6w-XtD6po",

  //======= Panel Setting =======//
  panel: {
    domain: "https://rexzzy-serverpublic.nezprivate.my.id/",
    apikey: "ptla_HKqy4nYH2llzItyFQ2zJASOeBGxAtuVq3tjxirWYETD",
    nestId: 5,
    eggId: 15,
    locationId: 1,
    startup: "npm start",
    image: "ghcr.io/parkervcp/yolks:nodejs_18"
  },

  reseller: {
    adminPanel: {
      monthly: 1100
    }
  },

  //======= Harga Panel =======//
  hargaPanel: {
    unlimited: 7000,
  }
};
