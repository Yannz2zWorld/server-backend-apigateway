require('../settings');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const FileType = require('file-type');
const PhoneNumber = require('awesome-phonenumber');

const { imageToWebp, videoToWebp, writeExif } = require('../library/exif');
const { isUrl, getGroupAdmins, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep, getTypeUrlMedia } = require('../library/function');
const { jidNormalizedUser, proto, getBinaryNodeChildren, getBinaryNodeChild, generateWAMessageContent, generateForwardMessageContent, prepareWAMessageMedia, delay, areJidsSameUser, extractMessageContent, generateMessageID, downloadContentFromMessage, generateWAMessageFromContent, jidDecode, generateWAMessage, toBuffer, getContentType, getDevice } = require('@whiskeysockets/baileys');

async function generateImage(prompt) {
    try {
        const encodedPrompt = encodeURIComponent(prompt.trim());
        const apiUrl = `${global.apialip}/imagecreator/bananagen?apikey=${global.apikeyalip}&prompt=${encodedPrompt}&model=auto`;
        const response = await axios.get(apiUrl, {
            responseType: 'arraybuffer',
            timeout: 120000
        });
        if (!response.data || response.data.length === 0) {
            throw new Error('Gagal mendapatkan gambar');
        }
        return Buffer.from(response.data);
    } catch (e) {
        throw e;
    }
}

async function putarMusikAi(queryMusik) {
    try {
        const apiUrl = `${global.apialip}/download/soundcloudplay?apikey=${global.apikeyalip}&query=${encodeURIComponent(queryMusik)}`;
        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;
        if (!data.status || !data.result || !data.result.audio) return null;
        
        const audioResponse = await axios.get(data.result.audio, { responseType: 'arraybuffer', timeout: 60000 });
        const audioBuffer = Buffer.from(audioResponse.data);
        
        return {
            success: true,
            title: data.result.title,
            artist: data.result.artist,
            audioBuffer: audioBuffer,
            duration: data.result.duration
        };
    } catch (e) {
        return null;
    }
}

async function cariGambarAi(queryGambar) {
    try {
        let url = `${global.apialip}/search/pinterest?apikey=${global.apikeyalip}&q=${encodeURIComponent(queryGambar)}`;
        let response = await axios.get(url);
        let results = (response.data.result || []).filter(v => typeof v === "string" && v.startsWith("http"));
        if (!results || results.length === 0) return null;
        let selectedImage = results[Math.floor(Math.random() * Math.min(results.length, 5))];
        return selectedImage;
    } catch (e) {
        return null;
    }
}

async function sendRichResponse(alip, chatId, text, mentions = [], quoted = null) {
    try {
        const ai = new alip.AIRich(alip);
        const hasTable = text.includes('|') && text.includes('\n') && text.split('\n').filter(l => l.includes('|')).length >= 2;
        const hasCode = text.includes('```');
        
        if (hasTable) {
            const lines = text.split('\n');
            const tableRows = [];
            for (const line of lines) {
                if (line.includes('|')) {
                    const cells = line.split('|').filter(c => c.trim());
                    if (cells.length >= 2) {
                        tableRows.push(cells.map(c => c.trim()));
                    }
                } else if (line.trim() && !line.includes('```')) {
                    ai.addText(line.trim());
                }
            }
            if (tableRows.length >= 2) {
                ai.addTable(tableRows);
            } else {
                ai.addText(text);
            }
        } else if (hasCode) {
            const codeMatch = text.match(/```(\w+)?\n([\s\S]*?)```/);
            if (codeMatch) {
                const lang = codeMatch[1] || 'javascript';
                const code = codeMatch[2].trim();
                ai.addCode(lang, code);
                const remainingText = text.replace(/```(\w+)?\n[\s\S]*?```/, '').trim();
                if (remainingText) ai.addText(remainingText);
            } else {
                ai.addText(text);
            }
        } else {
            let formattedText = text;
            formattedText = formattedText.replace(/\*\*(.*?)\*\*/g, '*$1*');
            formattedText = formattedText.replace(/^# (.*?)$/gm, '🔹 *$1*');
            formattedText = formattedText.replace(/^- (.*?)$/gm, '• $1');
            ai.addText(formattedText);
        }
        
        ai.addSuggest([`#${global.botname}`, `#autoai`]);
        await ai.send(chatId, { forwarded: true });
        return true;
    } catch (err) {
        await alip.sendMessage(chatId, { text: text, mentions: mentions }, { quoted });
        return false;
    }
}

async function getAiResponse(question, systemPrompt = null) {
    try {
        const encodedPrompt = encodeURIComponent(question);
        let apiUrl = `${global.apialip}/ai/gemini?apikey=${global.apikeyalip}&prompt=${encodedPrompt}`;
        
        if (systemPrompt) {
            apiUrl += `&system=${encodeURIComponent(systemPrompt)}`;
        }
        
        const response = await axios.get(apiUrl, { timeout: 9999000 });
        
        if (response.data?.status === true && response.data?.result) {
            return response.data.result;
        }
        throw new Error('Gagal mendapatkan respon');
    } catch (err) {
        console.error('[AI Error]', err.message);
        const fallbacks = [
            "Maaf, server AI sedang sibuk. Coba lagi nanti ya 😊",
            "Aku lagi gangguan koneksi nih. Tanyakan lagi nanti ya ✨",
            "Waduh, otakku lagi loading. Coba ulangi pertanyaannya dong 🙏"
        ];
        return fallbacks[Math.floor(Math.random() * fallbacks.length)];
    }
}

function extractShortName(fullName) {
    if (!fullName || typeof fullName !== 'string') return 'Kamu';
    const name = fullName.trim();
    if (name.length <= 12) return name;
    const spaceIndex = name.indexOf(' ');
    if (spaceIndex > 0 && spaceIndex <= 8) {
        return name.substring(0, spaceIndex);
    }
    return name.substring(0, 8);
}

function splitLongMessage(text, maxLength = 4000) {
    if (!text) return [];
    if (text.length <= maxLength) return [text];
    const parts = [];
    let current = '';
    const lines = text.split('\n');
    for (const line of lines) {
        if ((current + line + '\n').length > maxLength) {
            parts.push(current);
            current = line + '\n';
        } else {
            current += line + '\n';
        }
    }
    if (current) parts.push(current);
    return parts;
}

function getUserNameFromMetadata(m, userId) {
    if (!m.metadata || !m.metadata.participants) return null;
    const participant = m.metadata.participants.find(p => p.jid === userId || p.id === userId);
    if (participant && participant.notify) return participant.notify;
    if (participant && participant.name) return participant.name;
    return null;
}

function getGroupStats(chatId) {
    const levelDBPath = './library/database/level.json';
    let levelDB = {};
    if (fs.existsSync(levelDBPath)) {
        levelDB = JSON.parse(fs.readFileSync(levelDBPath));
    }
    const groupData = levelDB[chatId] || {};
    
    let totalMessages = 0;
    let activeMembers = 0;
    let topChatters = [];
    
    for (const [jid, data] of Object.entries(groupData)) {
        const messages = data.messages || 0;
        if (messages > 0) {
            totalMessages += messages;
            activeMembers++;
            topChatters.push({ jid, messages, name: data.name || jid.split('@')[0] });
        }
    }
    
    topChatters.sort((a, b) => b.messages - a.messages);
    topChatters = topChatters.slice(0, 5);
    
    return { totalMessages, activeMembers, topChatters };
}

class AutoAiHandler {
    constructor(alipInstance) {
        this.alip = alipInstance;
        this.botJid = this.alip.user.id;
        this.botName = global.botname || 'AI';
        this.settingsPath = './library/database/autoai_settings.json';
        this.historyPath = './library/database/autoai_history.json';
        this.settings = this.loadSettings();
        this.history = this.loadHistory();
        this.processing = new Map();
        this.lastResponseTime = new Map();
        this.lastAction = new Map();
        setInterval(() => this.cleanup(), 3600000);
    }

    loadSettings() {
        try {
            if (!fs.existsSync(this.settingsPath)) {
                const def = { enabledGroups: {}, cooldown: 2000, maxHistory: 50 };
                fs.writeFileSync(this.settingsPath, JSON.stringify(def, null, 2));
                return def;
            }
            return JSON.parse(fs.readFileSync(this.settingsPath));
        } catch (e) {
            return { enabledGroups: {}, cooldown: 2000, maxHistory: 50 };
        }
    }

    saveSettings() {
        try {
            fs.writeFileSync(this.settingsPath, JSON.stringify(this.settings, null, 2));
        } catch (e) {}
    }

    loadHistory() {
        try {
            if (!fs.existsSync(this.historyPath)) return {};
            return JSON.parse(fs.readFileSync(this.historyPath));
        } catch (e) {
            return {};
        }
    }

    saveHistory() {
        try {
            fs.writeFileSync(this.historyPath, JSON.stringify(this.history, null, 2));
        } catch (e) {}
    }

    isEnabled(groupId) {
        return this.settings.enabledGroups[groupId]?.enabled === true;
    }

    enable(groupId) {
        this.settings.enabledGroups[groupId] = { enabled: true, enabledAt: Date.now() };
        this.saveSettings();
        return true;
    }

    disable(groupId) {
        if (this.settings.enabledGroups[groupId]) {
            this.settings.enabledGroups[groupId].enabled = false;
            this.saveSettings();
        }
        return true;
    }

    getHistory(groupId) {
        if (!this.history[groupId]) this.history[groupId] = [];
        const max = this.settings.maxHistory || 50;
        if (this.history[groupId].length > max) {
            this.history[groupId] = this.history[groupId].slice(-max);
        }
        return this.history[groupId];
    }

    addToHistory(groupId, userId, userName, message, response, action = null, actionData = null) {
        const history = this.getHistory(groupId);
        history.push({
            userId, userName, message, response,
            action: action,
            actionData: actionData,
            timestamp: Date.now()
        });
        if (action) {
            this.lastAction.set(`${groupId}:${userId}`, { action, actionData, timestamp: Date.now() });
        }
        this.saveHistory();
    }

    clearHistory(groupId) {
        delete this.history[groupId];
        this.saveHistory();
        return true;
    }

    getLastAction(groupId, userId) {
        return this.lastAction.get(`${groupId}:${userId}`);
    }

    checkCooldown(userId, groupId) {
        const key = `${groupId}:${userId}`;
        const now = Date.now();
        const last = this.lastResponseTime.get(key) || 0;
        const cooldown = this.settings.cooldown || 2000;
        if (now - last < cooldown) return false;
        this.lastResponseTime.set(key, now);
        return true;
    }

    cleanup() {
        const now = Date.now();
        for (const [key, time] of this.lastResponseTime) {
            if (now - time > 60000) this.lastResponseTime.delete(key);
        }
        for (const [key, data] of this.lastAction) {
            if (now - data.timestamp > 300000) this.lastAction.delete(key);
        }
        for (const groupId in this.history) {
            const history = this.history[groupId];
            if (history.length > 0) {
                const last = history[history.length - 1].timestamp;
                if (now - last > 86400000) {
                    delete this.history[groupId];
                }
            }
        }
        this.saveHistory();
    }

    isReplyToBot(m) {
        if (!m.quoted) return false;
        const quoted = m.quoted;
        if (quoted.fromMe === true) return true;
        if (quoted.participant === this.botJid) return true;
        if (quoted.sender === this.botJid) return true;
        if (quoted.key?.fromMe === true) return true;
        if (quoted.key?.participant === this.botJid) return true;
        return false;
    }

    getConversationContext(groupId, currentUserId, currentUserName) {
        const history = this.getHistory(groupId);
        const recentHistory = history.slice(-20);
        
        let allUsers = new Map();
        let conversationFlow = [];
        let directConversation = [];
        
        for (const h of recentHistory) {
            if (!allUsers.has(h.userId)) {
                allUsers.set(h.userId, h.userName);
            }
            conversationFlow.push({
                user: h.userName,
                message: h.message,
                response: h.response,
                action: h.action,
                timestamp: h.timestamp
            });
            if (h.userId === currentUserId) {
                directConversation.push({
                    user: h.userName,
                    message: h.message,
                    response: h.response,
                    timestamp: h.timestamp
                });
            }
        }
        
        let contextText = '';
        if (conversationFlow.length > 0) {
            contextText = `\n\nSUASANA PERCAKAPAN DI GRUP (${conversationFlow.length} pesan terakhir):\n`;
            for (const c of conversationFlow) {
                contextText += `- ${c.user}: "${c.message}"\n`;
                if (c.response) {
                    contextText += `  ${this.botName}: "${c.response.substring(0, 100)}${c.response.length > 100 ? '...' : ''}"\n`;
                }
                if (c.action === 'play_music') {
                    contextText += `  [INFO: ${this.botName} TELAH MEMUTAR LAGU SEBELUMNYA]\n`;
                } else if (c.action === 'search_image') {
                    contextText += `  [INFO: ${this.botName} TELAH MENGIRIM GAMBAR SEBELUMNYA]\n`;
                } else if (c.action === 'generate_image') {
                    contextText += `  [INFO: ${this.botName} TELAH MEMBUAT GAMBAR SEBELUMNYA]\n`;
                }
            }
        }
        
        let directContext = '';
        if (directConversation.length > 0) {
            directContext = `\n\nPERCAKAPAN LANGSUNG DENGAN ${currentUserName.toUpperCase()}:\n`;
            for (const c of directConversation.slice(-5)) {
                directContext += `- ${c.user}: "${c.message}"\n`;
                if (c.response) {
                    directContext += `  ${this.botName}: "${c.response.substring(0, 100)}${c.response.length > 100 ? '...' : ''}"\n`;
                }
            }
        }
        
        const otherUsers = Array.from(allUsers.keys()).filter(id => id !== currentUserId);
        let otherUsersText = '';
        if (otherUsers.length > 0) {
            otherUsersText = `\n\nMEMBER LAIN YANG ADA DI GRUP:\n`;
            for (const uid of otherUsers.slice(0, 7)) {
                otherUsersText += `- ${allUsers.get(uid)}\n`;
            }
        }
        
        return { contextText, directContext, otherUsersText, allUsers, conversationFlow };
    }

    buildPrompt(groupId, userMessage, userName, userId, isCreator, isPremium) {
        const { contextText, directContext, otherUsersText, allUsers, conversationFlow } = this.getConversationContext(groupId, userId, userName);
        const lastAction = this.getLastAction(groupId, userId);
        
        let actionContext = '';
        if (lastAction) {
            const timeDiff = Math.floor((Date.now() - lastAction.timestamp) / 1000);
            if (timeDiff < 300) {
                if (lastAction.action === 'play_music') {
                    actionContext = `\n\nKONTEKS: Kamu baru saja memutar lagu "${lastAction.actionData?.title || 'lagu'}" untuk ${userName} ${timeDiff} detik yang lalu.`;
                } else if (lastAction.action === 'search_image') {
                    actionContext = `\n\nKONTEKS: Kamu baru saja mengirim gambar tentang "${lastAction.actionData?.query || 'gambar'}" untuk ${userName} ${timeDiff} detik yang lalu.`;
                } else if (lastAction.action === 'generate_image') {
                    actionContext = `\n\nKONTEKS: Kamu baru saja membuat gambar dengan prompt "${lastAction.actionData?.prompt || 'gambar'}" untuk ${userName} ${timeDiff} detik yang lalu.`;
                }
            }
        }
        
        let groupName = 'Grup Ini';
        let groupInfo = '';
        let groupStats = '';
        
        if (this.alip.metadata && this.alip.metadata[groupId]) {
            const meta = this.alip.metadata[groupId];
            groupName = meta.subject || groupName;
            const totalMembers = meta.participants?.length || 0;
            const isClosed = meta.announce ? 'Tertutup (Hanya Admin)' : 'Terbuka';
            const createdAt = meta.creation ? new Date(meta.creation * 1000).toLocaleDateString('id-ID') : 'Tidak diketahui';
            
            groupInfo = `\n- Info Grup: ${groupName} | ${totalMembers} member | Mode: ${isClosed} | Dibuat: ${createdAt}`;
            
            const stats = getGroupStats(groupId);
            if (stats.totalMessages > 0) {
                groupStats = `\n- Statistik Grup: Total ${stats.totalMessages.toLocaleString()} pesan dari ${stats.activeMembers} member aktif`;
                if (stats.topChatters.length > 0) {
                    groupStats += `\n- Top 3 Member Aktif: ${stats.topChatters.slice(0,3).map(t => t.name.split(' ')[0]).join(', ')}`;
                }
            }
        }
        
        let userStatus = 'Member Biasa';
        if (isCreator) userStatus = 'OWNER BOT';
        else if (isPremium) userStatus = 'Member Premium';
        
        let systemInfo = `- Nama Bot: ${this.botName}\n- Nama Grup: ${groupName}\n- Status ${userName}: ${userStatus}${groupInfo}${groupStats}`;
        
        try {
            const sewaPath = './library/database/sewagrup.json';
            if (fs.existsSync(sewaPath)) {
                const sewagrup = JSON.parse(fs.readFileSync(sewaPath));
                const sewa = sewagrup.find(v => v.jid === groupId);
                if (sewa && sewa.expired > Date.now()) {
                    const sisaHari = Math.floor((sewa.expired - Date.now()) / (86400000));
                    systemInfo += `\n- Sewa Grup: Aktif (${sisaHari} hari)`;
                }
            }
        } catch(e) {}
        
        let recentTopics = '';
        if (conversationFlow.length > 3) {
            const topics = [];
            for (const c of conversationFlow.slice(-8)) {
                if (c.message.length > 5 && !c.message.includes('PLAYMUSIC') && !c.message.includes('CARIFOTO') && !c.message.includes('BUATGAMBAR')) {
                    topics.push(c.message.substring(0, 50));
                }
            }
            if (topics.length > 0) {
                recentTopics = `\n\nTOPIK YANG BARU SAJA DIBICARAKAN DI GRUP:\n- ${topics.join('\n- ')}`;
            }
        }
        
        return `Kamu adalah ${this.botName} - asisten AI WhatsApp yang super asik, ramah, dan bisa diajak ngobrol santai kayak teman curhat. Kamu BUKAN robot, kamu teman ngobrol yang asik dan punya kepribadian.

${systemInfo}${contextText}${directContext}${otherUsersText}${recentTopics}${actionContext}

KARAKTER KAMU:
- Nama kamu: ${this.botName}
- Kamu super asik, friendly, dan bisa diajak becanda
- Kamu tahu nama semua member yang ngobrol sama kamu
- Kamu tahu suasana grup dan percakapan sebelumnya
- Kamu bisa bedain satu user dengan user lain
- Kamu tau kalo user lagi ngomongin kamu atau nanya ke kamu
- Kamu paham konteks obrolan yang lagi rame di grup

ATURAN PENTING:
1. Panggil user dengan nama mereka masing-masing (${userName} untuk user ini)
2. Gunakan bahasa Indonesia natural, santai, gaul, kayak ngobrol sama teman
3. Jawab SINGKAT, PADAT, LANGSUNG ke inti (maksimal 3-4 kalimat)
4. Boleh pake emoji biar lebih seru
5. GUNAKAN MARKDOWN UNTUK MEMPERCANTIK RESPON:
   - Gunakan **teks tebal** untuk penekanan
   - Gunakan *teks miring* untuk istilah asing
   - Gunakan > untuk quote
   - Gunakan - atau • untuk membuat list
   - Gunakan | untuk membuat tabel sederhana
   - Gunakan \`code\` untuk command
6. JANGAN sebut "AI" atau "asisten" - Kamu adalah ${this.botName}
7. Bisa becanda asal ga keterlaluan
8. RESPON HARUS NATURAL DAN KAYAK MANUSIA BENERAN
9. Kalo lagi rame-rame ngobrol, kamu bisa ikut nimbrung sesuai topik

FORMAT KEMAMPUAN KHUSUS (WAJIB):
- Jika user minta putar musik (contoh: "putar lagu dewa"), kamu WAJIB balas dengan: [PLAYMUSIC: judul lagu]
  Contoh: "Oke bos, bentar gua cariin lagu nya dulu ya! 🎵 [PLAYMUSIC: dewa 19]"
  
- Jika user minta cari gambar (contoh: "cari foto kucing"), kamu WAJIB balas dengan: [CARIFOTO: topik gambar]
  Contoh: "Siap! Lagi aku cariin gambar kucing lucu nih 🐱 [CARIFOTO: kucing lucu]"
  
- Jika user minta buat gambar (contoh: "buatin gambar pemandangan"), WAJIB balas dengan: [BUATGAMBAR: deskripsi]
  Contoh: "Wah menarik! Lagi aku buatin gambar pemandangan buat kamu nih 🎨 [BUATGAMBAR: pemandangan gunung dan danau]"

Pesan dari ${userName}: "${userMessage}"

Balasan ${this.botName} (gunakan markdown, natural, maksimal 3-4 kalimat):`;
    }

    async processMessage(m, isCmd, isCreator, isPremium) {
        if (!m.isGroup) return;
        
        const processKey = `${m.chat}:${m.sender}`;
        if (this.processing.get(processKey)) return;
        this.processing.set(processKey, true);
        
        try {
            const isGroup = m.isGroup;
            const chatId = m.chat;
            
            if (isGroup && !this.isEnabled(chatId)) return;
            
            if (m.isBot || m.fromMe) return;
            if (isCmd) return;
            
            if (isGroup && !this.isReplyToBot(m)) return;
            
            if (!m.text || m.text.trim().length < 2) return;
            
            if (!this.checkCooldown(m.sender, chatId)) return;
            
            if (global.gameSessions?.[chatId] || global.mathQuizSessions?.[m.sender]) return;
            
            let userName = m.pushName || m.sender.split('@')[0];
            if (isGroup && m.metadata) {
                const metaName = getUserNameFromMetadata(m, m.sender);
                if (metaName) userName = metaName;
            }
            const shortName = extractShortName(userName);
            
            if (isGroup && m.metadata && !this.alip.metadata) this.alip.metadata = {};
            if (isGroup && m.metadata) this.alip.metadata[chatId] = m.metadata;
            
            await this.alip.sendMessage(chatId, { react: { text: "💭", key: m.key } }).catch(() => {});
            
            const prompt = this.buildPrompt(chatId, m.text, shortName, m.sender, isCreator, isPremium);
            
            let aiResponse = await getAiResponse(prompt);
            
            await new Promise(r => setTimeout(r, 500));
            
            await this.alip.sendPresenceUpdate('composing', chatId).catch(() => {});
            
            let playMusicMatch = aiResponse.match(/\[PLAYMUSIC:(.*?)\]/i);
            let searchImageMatch = aiResponse.match(/\[CARIFOTO:(.*?)\]/i);
            let generateImageMatch = aiResponse.match(/\[BUATGAMBAR:(.*?)\]/i);
            
            let textResponse = aiResponse
                .replace(/\[PLAYMUSIC:.*?\]/gi, '')
                .replace(/\[CARIFOTO:.*?\]/gi, '')
                .replace(/\[BUATGAMBAR:.*?\]/gi, '')
                .trim();
            
            if (!textResponse && (playMusicMatch || searchImageMatch || generateImageMatch)) {
                textResponse = "Oke, tunggu sebentar ya! ⏳";
            }
            
            if (playMusicMatch && playMusicMatch[1]) {
                const query = playMusicMatch[1].trim();
                
                if (textResponse) {
                    await sendRichResponse(this.alip, chatId, textResponse, [m.sender], m);
                }
                
                await this.alip.sendMessage(chatId, { react: { text: "🎵", key: m.key } }).catch(() => {});
                
                const result = await putarMusikAi(query);
                
                if (result && result.success) {
                    this.addToHistory(chatId, m.sender, shortName, m.text, textResponse, 'play_music', { title: result.title, artist: result.artist, query: query });
                    
                    await this.alip.sendMessage(chatId, {
                        audio: result.audioBuffer,
                        mimetype: 'audio/mpeg',
                        ptt: false,
                        contextInfo: {
                            isForwarded: true,
                            forwardingScore: 9999,
                            businessMessageForwardInfo: { businessOwnerJid: global.owner + "@s.whatsapp.net" },
                            forwardedNewsletterMessageInfo: {
                                newsletterName: result.title || 'Musik',
                                newsletterJid: global.idSaluran
                            }
                        }
                    }, { quoted: m }).catch(() => {});
                    
                    await new Promise(r => setTimeout(r, 1000));
                    
                    await sendRichResponse(this.alip, chatId, `Nah gimana bos? lagu *${result.title}* udah kekirim tuh! 🎵\nEnak kan lagunya? ${result.artist} emang juara sih! 🔥`, [m.sender], m);
                } else {
                    await sendRichResponse(this.alip, chatId, `Maaf bos, lagu "${query}" gak ketemu nih 😢\nCoba cari judul lain atau penyanyi lain ya! 🎵`, [m.sender], m);
                }
            } 
            else if (searchImageMatch && searchImageMatch[1]) {
                const query = searchImageMatch[1].trim();
                await this.alip.sendMessage(chatId, { react: { text: "🔍", key: m.key } }).catch(() => {});
                
                const imageUrl = await cariGambarAi(query);
                
                if (imageUrl) {
                    this.addToHistory(chatId, m.sender, shortName, m.text, textResponse, 'search_image', { query: query });
                    
                    let finalCaption = `Nih bos, gambar *${query}* udah ketemu! 🖼️\nSemoga kamu suka ya~`;
                    
                    await this.alip.sendMessage(chatId, {
                        image: { url: imageUrl },
                        caption: finalCaption,
                        mentions: [m.sender]
                    }, { quoted: m }).catch(() => {});
                } else {
                    await sendRichResponse(this.alip, chatId, `Maaf bos, gambar *${query}* gak ketemu nih 😢\nCoba pake kata kunci lain ya! 🔍`, [m.sender], m);
                }
            }
            else if (generateImageMatch && generateImageMatch[1]) {
                const query = generateImageMatch[1].trim();
                await this.alip.sendMessage(chatId, { react: { text: "🎨", key: m.key } }).catch(() => {});
                
                if (textResponse) {
                    await sendRichResponse(this.alip, chatId, textResponse, [m.sender], m);
                }
                
                try {
                    const imageBuffer = await generateImage(query);
                    this.addToHistory(chatId, m.sender, shortName, m.text, textResponse, 'generate_image', { prompt: query });
                    
                    let finalCaption = `Nah ini dia hasilnya bos! gambar *${query}* udah jadi! 🎨✨\nKeren gak nih hasilnya?`;
                    
                    await this.alip.sendMessage(chatId, {
                        image: imageBuffer,
                        caption: finalCaption,
                        mentions: [m.sender]
                    }, { quoted: m }).catch(() => {});
                } catch (err) {
                    await sendRichResponse(this.alip, chatId, `Maaf bos, gambar *${query}* gagal dibuat nih 😢\nCoba dengan deskripsi yang lebih jelas ya! 🎨`, [m.sender], m);
                }
            }
            else {
                this.addToHistory(chatId, m.sender, shortName, m.text, textResponse);
                if (textResponse) {
                    await sendRichResponse(this.alip, chatId, textResponse, [m.sender], m);
                }
            }
            
            await this.alip.sendPresenceUpdate('paused', chatId).catch(() => {});
            await this.alip.sendMessage(chatId, { react: { text: "✅", key: m.key } }).catch(() => {});
            
        } catch (err) {
            console.error('[AutoAI Error]', err);
        } finally {
            setTimeout(() => this.processing.delete(processKey), 1000);
        }
    }
    
    handleCommand(m, text) {
        if (!m.isGroup) return '❌ Command ini hanya untuk grup!';
        const isAdmin = m.isAdmin || m.isDeveloper || m.sender.includes(global.owner);
        if (!isAdmin) return '❌ Hanya admin grup!';
        
        const action = text?.split(' ')[0]?.toLowerCase();
        
        if (!action) {
            const status = this.isEnabled(m.chat) ? '✅ AKTIF' : '❌ NONAKTIF';
            const history = this.getHistory(m.chat);
            const stats = getGroupStats(m.chat);
            const groupName = m.metadata?.subject || 'Grup';
            return `🤖 *AUTOAI ${groupName.toUpperCase()}*\n\nStatus: ${status}\nMemory: ${history.length} pesan\nTotal Chat Grup: ${stats.totalMessages.toLocaleString()} pesan\nMember Aktif: ${stats.activeMembers}\n\n.autoai on → Aktifkan\n.autoai off → Matikan\n.autoai clear → Hapus memory`;
        }
        
        if (action === 'on') {
            this.enable(m.chat);
            return `✅ *AUTOAI AKTIF!*\n\nSekarang ${this.botName} bakal ngobrol asik sama yang reply pesan ${this.botName}. Yuk ngobrol seru! 🎉`;
        }
        if (action === 'off') {
            this.disable(m.chat);
            return `❌ *AUTOAI MATI*\n\n${this.botName} gak akan merespon lagi di grup ini. Kalo mau ngobrol lagi bisa aktifin ulang ya!`;
        }
        if (action === 'clear') {
            this.clearHistory(m.chat);
            return `🧹 *MEMORY DIHAPUS*\n\n${this.botName} lupa semua percakapan sebelumnya di grup ini. Mulai dari awal lagi yuk!`;
        }
        
        return `Gunakan: .autoai on / off / clear`;
    }
}

async function LoadDatabase(alip, m) {
    try {
        const botNumber = await alip.decodeJid(alip.user.id);
        const isNumber = x => typeof x === 'number' && !isNaN(x)
        const isBoolean = x => typeof x === 'boolean' && Boolean(x)

        let setBot = global.db.settings
        if (typeof setBot !== 'object') global.db.settings = {}
        if (setBot) {
            if (!('autoread' in setBot)) setBot.autoread = false
            if (!('autotyping' in setBot)) setBot.autotyping = false
            if (!('isPublic' in setBot)) setBot.isPublic = false
        } else {
            global.db.settings = {
                autoread: false,
                autotyping: false,
                isPublic: false,
            }
        }
        let user = global.db.users[m.sender]
        if (typeof user !== 'object') global.db.users[m.sender] = {}
        if (!user) {
            global.db.users[m.sender] = {}
        }
        if (m.isGroup) {
            let group = global.db.groups[m.chat]
            if (typeof group !== 'object') global.db.groups[m.chat] = {}
            if (group) {
                if (!('antilink' in group)) group.antilink = false
                if (!('antilink2' in group)) group.antilink2 = false
                if (!('antilinkAll' in group)) group.antilinkAll = false
                if (!('antilinkCapcut' in group)) group.antilinkCapcut = false
                if (!('welcome' in group)) group.welcome = false
                if (!('left' in group)) group.left = false
                if (!('mute' in group)) group.mute = false
                if (!('blacklistjpm' in group)) group.blacklistjpm = false
                if (!('antiPromosi' in group)) group.antiPromosi = false
                if (!('antiToxic' in group)) group.antiToxic = false
                if (!('antiToxicKick' in group)) group.antiToxicKick = false
                if (!('antitagsw' in group)) group.antitagsw = false
                if (!('autodownload' in group)) group.autodownload = true
                if (!('antitagswkick' in group)) group.antitagswkick = false 
                if (!('antivideo' in group)) group.antivideo = false
                if (!('antifoto' in group)) group.antifoto = false
                if (!('antibot' in group)) group.antibot = false
                if (!('antibotkick' in group)) group.antibotkick = false
                if (!('onlyAdminMode' in group)) group.onlyAdminMode = false
                if (!('antiaudio' in group)) group.antiaudio = false
                if (!('antiswgc' in group)) group.antiswgc = false 
                if (!('antivirtex' in group)) group.antivirtex = false
            } else {
                global.db.groups[m.chat] = {
                    antilink: false,
                    antilink2: false,
                    antilinkAll: false,
                    antilinkCapcut: false,
                    welcome: false,
                    left: false,
                    mute: false,
                    blacklistjpm: false,
                    antiPromosi: false,
                    antiToxic: false,
                    antiToxicKick: false,
                    antitagsw: false,
                    antitagswkick: false, 
                    autodownload: true, 
                    antivideo: false,
                    antifoto: false,
                    antibot: false,
                    antibotkick: false,
                    onlyAdminMode: false,
                    antiaudio: false,
                    antiswgc: false,
                    antivirtex: false
                }
            }
        }
    } catch (e) {
        throw e;
    }
}

async function MessagesUpset(alip, message, store) {
    try {
        let botNumber = await alip.decodeJid(alip.user.id);
        const msg = message.messages[0];
        const remoteJid = msg.key.remoteJid;
        
        store.messages[remoteJid] ??= {};
        store.messages[remoteJid].array ??= [];
        store.messages[remoteJid].keyId ??= new Set();
        
        if (!(store.messages[remoteJid].keyId instanceof Set)) {
            store.messages[remoteJid].keyId = new Set(store.messages[remoteJid].array.map(m => m.key.id));
        }
        
        if (store.messages[remoteJid].keyId.has(msg.key.id)) return;
        store.messages[remoteJid].array.push(msg);
        store.messages[remoteJid].keyId.add(msg.key.id);
        
        if (store.messages[remoteJid].array.length > (global.chatLength || 250)) {
            const removed = store.messages[remoteJid].array.shift();
            store.messages[remoteJid].keyId.delete(removed.key.id);
        }

        const type = msg.message ? (getContentType(msg.message) || Object.keys(msg.message)[0]) : '';

        if (msg.key?.remoteJid === 'status@broadcast') {
            try {
                const dbPath = './library/database/autoreact.json';
                let isAutoReact = false;
                if (fs.existsSync(dbPath)) {
                    isAutoReact = JSON.parse(fs.readFileSync(dbPath)).status;
                }
                if (isAutoReact) {
                    alip.readMessages([msg.key]).catch(() => {});
                    const emojis = ['😱', '❤️', '😂', '😮', '😹', '🍌', '🫦'];
                    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
                    
                    setTimeout(async () => {
                        const targetJid = msg.key.participant || msg.participant || msg.sender;
                        if (targetJid && !msg.key.fromMe) {
                            await alip.sendMessage(targetJid, { 
                                react: { text: randomEmoji, key: msg.key } 
                            }).catch(() => {});
                        }
                    }, Math.floor(Math.random() * 3000) + 2000); 
                } 
                else if (global.db.settings.readsw === true) {
                    await alip.readMessages([msg.key]).catch(() => {});
                }
            } catch (e) {
                console.log('Error di Auto React SW (message.js):', e);
            }
            return; 
        }
        if (!msg.message) return;
        if (!alip.public && !msg.key.fromMe && message.type === 'notify') {
            const sender = alip.decodeJid(msg.key.participant || msg.key.remoteJid || '');
            const ownerList = [
                ...(global.owners || []), 
                global.owner
            ].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');

            if (!ownerList.includes(sender)) return;
        }

        if (global.db.settings.autoread === true) {
            await alip.readMessages([msg.key]);
        }

        if (global.db.settings.autotyping === true && !msg.key.fromMe) {
            await alip.sendPresenceUpdate('composing', msg.key.remoteJid);
        }

        const m = await Serialize(alip, msg, store);
        
        if (!global.autoAiHandler) {
    global.autoAiHandler = new AutoAiHandler(alip);
} else {
    global.autoAiHandler.alip = alip;
}
        
        require('../alipai-cmd.js')(alip, m, message, store);

        if (type === 'interactiveResponseMessage' && m.quoted && m.quoted.fromMe) {
            const parsedId = JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id;

            let apb = await generateWAMessage(
                m.chat,
                { text: parsedId, mentions: m.mentionedJid },
                { userJid: alip.user.id, quoted: m.quoted }
            );

            apb.key = msg.key;
            apb.key.fromMe = areJidsSameUser(m.sender, alip.user.id);
            if (m.isGroup) apb.participant = m.sender;

            let pbr = {
                ...msg,
                messages: [proto.WebMessageInfo.fromObject(apb)],
                type: 'append'
            };

            alip.ev.emit('messages.upsert', pbr);
        }
    } catch (e) {
        throw e;
    }
}

async function SolvingHendler(alip, store) {
    alip.public = global.db.settings.isPublic;
    
    alip.serializeM = (m) => MessagesUpset(alip, m, store)
    
    alip.decodeJid = (jid) => {
        if (!jid) return jid
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {}
            return decode.user && decode.server && decode.user + '@' + decode.server || jid
        } else return jid
    }
    
    alip.getName = async (jid, withoutContact = false) => {
        try {
            const id = alip.decodeJid(jid);
            if (id.endsWith('@g.us')) {
                const groupInfo = store.contacts[id] || await alip.groupMetadata(id).catch(_ => ({})) || {};
                return groupInfo.subject || groupInfo.name || PhoneNumber('+' + id.replace('@g.us', '')).getNumber('international');
            } else {
                if (id === '0@s.whatsapp.net') return 'WhatsApp';
                const contactInfo = store.contacts[id] || {};
                return withoutContact ? '' : contactInfo.name || contactInfo.verifiedName || contactInfo.notify || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international');
            }
        } catch {
            return jid.split('@')[0];
        }
    }
    
    alip.sendContactV2 = async (jid, kon, desk = "Developer Bot", quoted = '', opts = {}) => {
        let list = []
        for (let i of kon) {
            list.push({
                displayName: global.namaOwner,
                vcard: 'BEGIN:VCARD\n' +
                    'VERSION:3.0\n' +
                    `N:;${global.namaOwner};;;\n` +
                    `FN:${global.namaOwner}\n` +
                    'ORG:null\n' +
                    'TITLE:\n' +
                    `item1.TEL;waid=${i}:${i}\n` +
                    'item1.X-ABLabel:Ponsel\n' +
                    `X-WA-BIZ-DESCRIPTION:${desk}\n` +
                    `X-WA-BIZ-NAME:${global.namaOwner}\n` +
                    'END:VCARD'
            })
        }
        alip.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
    }
    
    alip.sendContact = async (jid, kon, quoted = '', opts = {}) => {
        let list = []
        for (let i of kon) {
            list.push({
                displayName: await alip.getName(i + '@s.whatsapp.net'),
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await alip.getName(i + '@s.whatsapp.net')}\nFN:${await alip.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.ADR:;;Indonesia;;;;\nitem2.X-ABLabel:Region\nEND:VCARD`
            })
        }
        alip.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
    }
    
    alip.profilePictureUrl = async (jid, type = 'image', timeoutMs) => {
        try {
            const result = await alip.query({
                tag: 'iq',
                attrs: {
                    target: jidNormalizedUser(jid),
                    to: '@s.whatsapp.net',
                    type: 'get',
                    xmlns: 'w:profile:picture'
                },
                content: [{
                    tag: 'picture',
                    attrs: {
                        type, query: 'url'
                    },
                }]
            }, timeoutMs);
            const child = getBinaryNodeChild(result, 'picture');
            return child?.attrs?.url;
        } catch {
            return null;
        }
    }
    
    alip.setStatus = (status) => {
        alip.query({
            tag: 'iq',
            attrs: {
                to: '@s.whatsapp.net',
                type: 'set',
                xmlns: 'status',
            },
            content: [{
                tag: 'status',
                attrs: {},
                content: Buffer.from(status, 'utf-8')
            }]
        })
        return status
    }
    
    alip.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
        const quotedOptions = { quoted }
        async function getFileUrl(res, mime) {
            if (mime && mime.includes('gif')) {
                return alip.sendMessage(jid, { video: res.data, caption: caption, gifPlayback: true, ...options }, quotedOptions);
            } else if (mime && mime === 'application/pdf') {
                return alip.sendMessage(jid, { document: res.data, mimetype: 'application/pdf', caption: caption, ...options }, quotedOptions);
            } else if (mime && mime.includes('image')) {
                return alip.sendMessage(jid, { image: res.data, caption: caption, ...options }, quotedOptions);
            } else if (mime && mime.includes('video')) {
                return alip.sendMessage(jid, { video: res.data, caption: caption, mimetype: 'video/mp4', ...options }, quotedOptions);
            } else if (mime && mime.includes('webp') && !/.jpg|.jpeg|.png/.test(url)) {
                return alip.sendAsSticker(jid, res.data, quoted, options);
            } else if (mime && mime.includes('audio')) {
                return alip.sendMessage(jid, { audio: res.data, mimetype: 'audio/mpeg', ...options }, quotedOptions);
            } else {
                return alip.sendMessage(jid, { document: res.data, mimetype: mime, fileName: url.split('/').pop(), caption: caption, ...options }, quotedOptions);
            }
        }
        
        try {
            const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000 });
            let mime = res.headers['content-type'];
            if (!mime || mime.includes('octet-stream')) {
                const fileType = await FileType.fromBuffer(res.data);
                mime = fileType ? fileType.mime : 'application/octet-stream';
            }
            const hasil = await getFileUrl(res, mime);
            return hasil
        } catch (error) {
            throw new Error(`Failed to download file: ${error.message}`);
        }
    }
    
    alip.sendTextMentions = async (jid, text, quoted, options = {}) => alip.sendMessage(jid, { text: text, mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), ...options }, { quoted })
    
    alip.sendAsSticker = async (jid, path, quoted, options = {}) => {
        const buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExif(buff, options);
        } else {
            buffer = await videoToWebp(buff);
        }
        await alip.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buff;
    }
    
    alip.downloadMediaMessage = async (message) => {
        try {
            const msg = message.msg || message;
            const mime = msg.mimetype || '';
            const messageType = (message.type || mime.split('/')[0]).replace(/Message/gi, '');
            const stream = await downloadContentFromMessage(msg, messageType);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            return buffer
        } catch (error) {
            throw new Error(`Failed to download media: ${error.message}`);
        }
    }
    
    alip.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        const buffer = await alip.downloadMediaMessage(message);
        const type = await FileType.fromBuffer(buffer);
        const trueFileName = attachExtension ? `./library/database/sampah/${filename ? filename : Date.now()}.${type.ext}` : filename;
        await fs.promises.writeFile(trueFileName, buffer);
        return trueFileName;
    }
    
    alip.getFile = async (PATH, save) => {
        let res;
        let filename;
        let data = Buffer.isBuffer(PATH) ? PATH : 
                   /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : 
                   /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : 
                   fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : 
                   typeof PATH === 'string' ? PATH : Buffer.alloc(0)
        
        let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' }
        filename = path.join(__filename, '../library/database/sampah/' + new Date * 1 + '.' + type.ext)
        if (data && save) fs.promises.writeFile(filename, data)
        return {
            res,
            filename,
            size: await getSizeMedia(data),
            ...type,
            data
        }
    }
    
    alip.sendMedia = async (jid, path, fileName = '', caption = '', quoted = '', options = {}) => {
        const { mime, data, filename } = await alip.getFile(path, true);
        const isWebpSticker = options.asSticker || /webp/.test(mime);
        let type = 'document', mimetype = mime, pathFile = filename;
        
        if (isWebpSticker) {
            const { writeExif } = require('../library/exif');
            const media = { mimetype: mime, data };
            pathFile = await writeExif(media, {
                packname: options.packname || global.packname,
                author: options.author || global.author,
                categories: options.categories || [],
            })
            await fs.promises.unlink(filename);
            type = 'sticker';
            mimetype = 'image/webp';
        } else if (/image|video|audio/.test(mime)) {
            type = mime.split('/')[0];
            mimetype = type == 'video' ? 'video/mp4' : type == 'audio' ? 'audio/mpeg' : mime
        }
        
        let anu = await alip.sendMessage(jid, { [type]: { url: pathFile }, caption, mimetype, fileName, ...options }, { quoted, ...options });
        await fs.promises.unlink(pathFile);
        return anu;
    }
    
    alip.appendResponseMessage = async (m, text) => {
        let apb = await generateWAMessage(m.chat, { text, mentions: m.mentionedJid }, { userJid: alip.user.id, quoted: m.quoted && m.quoted.fakeObj });
        apb.key = m.key
        apb.key.id = [...Array(32)].map(() => '0123456789ABCDEF'[Math.floor(Math.random() * 16)]).join('');
        apb.key.fromMe = areJidsSameUser(m.sender, alip.user.id);
        if (m.isGroup) apb.participant = m.sender;
        alip.ev.emit('messages.upsert', {
            ...m,
            messages: [proto.WebMessageInfo.fromObject(apb)],
            type: 'append'
        });
    }
    
    return alip
}

async function Serialize(alip, msg, store) {
    const botLid = alip.decodeJid(alip.user.lid);
    const botNumber = alip.decodeJid(alip.user.id);
    const botrunning = global.owner + '@s.whatsapp.net';
    if (!msg) return msg
    const m = { ...msg };

    if (m.key) {
        m.id = m.key.id
        m.chat = m.key.remoteJid
        m.fromMe = m.key.fromMe
        m.isBaileys = m.id ? (m.id.startsWith('3EB0') || m.id.startsWith('B1E') || m.id.startsWith('BAE') || m.id.startsWith('3F8') || m.id.length < 32) : false
        
        m.isBot = ['HSK', 'BAE', 'B1E', '3EB0', 'B24E', 'WA'].some(a => m.id.startsWith(a) && [12, 16, 20, 22, 40].includes(m.id.length)) || /(.)\1{5,}|[^a-zA-Z0-9]|[^0-9A-F]/.test(m.id) || false
        
        m.isGroup = m.chat.endsWith('@g.us')
        m.sender = alip.decodeJid(m.fromMe && alip.user.id || m.key.participant || m.chat || '')

        if (m.isGroup) {
            try {
                m.metadata = await alip.groupMetadata(m.chat)
            } catch {
                m.metadata = {}
            }
                
            if (m.metadata.addressingMode === 'lid') {
                const participant = m.metadata.participants.find(a => a.lid === m.sender)
                m.key.participant = m.sender = participant?.id || m.sender; 
            }
            
            const admins = []
            if (m.metadata?.participants) {
                for (let p of m.metadata.participants) {
                    if (p.admin !== null) {
                        if (p.jid) admins.push(p.jid)
                        if (p.id) admins.push(p.id)
                        if (p.lid) admins.push(p.lid)
                    }
                }
            }
            m.admins = admins
            const checkAdmin = (jid, list) =>
                list.some(x =>
                    x === jid ||
                    (jid.endsWith('@s.whatsapp.net') && x === jid.replace('@s.whatsapp.net', '@lid')) ||
                    (jid.endsWith('@lid') && x === jid.replace('@lid', '@s.whatsapp.net'))
                )
            m.isAdmin = checkAdmin(m.sender, m.admins)
            m.isBotAdmin = checkAdmin(botNumber, m.admins)
            m.participant = m.key.participant || ""
        }

        m.isDeveloper = botrunning.includes(m.sender) ? true : false
    }

    if (m.message) {
        m.type = getContentType(m.message) || Object.keys(m.message)[0]
        m.msg = (/viewOnceMessage|viewOnceMessageV2Extension|editedMessage|ephemeralMessage/i.test(m.type) 
            ? m.message[m.type].message[getContentType(m.message[m.type].message)] 
            : (extractMessageContent(m.message[m.type]) || m.message[m.type]))

        let interactiveData = {}

        if (m.msg?.interactiveResponseMessage?.paramsJson) {
            try {
                interactiveData = JSON.parse(m.msg.interactiveResponseMessage.paramsJson)
            } catch (e) {
                interactiveData = {}
            }
        }

        if (m.msg?.nativeFlowResponseMessage?.paramsJson) {
            try {
                const nativeParams = JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson)
                interactiveData = { ...interactiveData, ...nativeParams }
            } catch (e) {
            }
        }

        m.interactive = interactiveData
        
        m.body = m.message?.conversation || 
                 m.msg?.text || 
                 m.msg?.conversation || 
                 m.msg?.caption || 
                 m.msg?.selectedButtonId || 
                 m.msg?.singleSelectReply?.selectedRowId || 
                 m.msg?.selectedId || 
                 m.msg?.contentText || 
                 m.msg?.selectedDisplayText || 
                 m.msg?.title || 
                 m.msg?.name || 
                 m.msg?.description || 
                 ''

        m.mentionedJid = m.msg?.contextInfo?.mentionedJid || []
        m.text = m.msg?.text || 
                 m.msg?.caption || 
                 m.message?.conversation || 
                 m.msg?.contentText || 
                 m.msg?.selectedDisplayText || 
                 m.msg?.title || 
                 m.msg?.description || 
                 '';

        m.prefix = /^[Â°â€¢Ï€Ă·Ă—Â¶âˆ†Â£Â¢â‚¬Â¥Â®â„¢+âœ“_=|~!?@#$%^&.Â©^]/gi.test(m.body) ? 
                   m.body.match(/^[Â°â€¢Ï€Ă·Ă—Â¶âˆ†Â£Â¢â‚¬Â¥Â®â„¢+âœ“_=|~!?@#$%^&.Â©^]/gi)[0] : 
                   /[\uD800-\uDBFF][\uDC00-\uDFFF]/gi.test(m.body) ? 
                   m.body.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/gi)[0] : ''

        m.command = m.body && m.body.replace(m.prefix, '').trim().split(/ +/).shift()
        m.args = m.body?.trim().replace(new RegExp("^" + m.prefix?.replace(/[.*=+:\-?^${}()|[\]\\]|\s/g, '\\$&'), 'i'), '')
                    .replace(m.command, '').split(/ +/).filter(a => a) || []

        m.device = getDevice(m.id)
        m.expiration = m.msg?.contextInfo?.expiration || 0
        
        m.timestamp = (typeof m.messageTimestamp === 'number' 
            ? m.messageTimestamp 
            : m.messageTimestamp?.low 
            ? m.messageTimestamp.low 
            : m.messageTimestamp?.high) || m.msg.timestampMs * 1000

        m.isMedia = !!m.msg?.mimetype || !!m.msg?.thumbnailDirectPath || !!m.msg?.jpegThumbnail
        if (m.isMedia) {
            m.mime = m.msg?.mimetype
            m.size = m.msg?.fileLength
            m.height = m.msg?.height || ''
            m.width = m.msg?.width || ''
            if (/webp/i.test(m.mime)) {
                m.isAnimated = m.msg?.isAnimated
            }
        }

        m.quoted = m.msg?.contextInfo?.quotedMessage || null
        if (m.quoted) {
            if (m.isGroup && m.msg?.contextInfo?.participant?.endsWith('@lid')) { 
                m.msg.contextInfo.participant =  m?.metadata?.participants?.find(a => a.lid === m.msg.contextInfo.participant)?.id || m.msg.contextInfo.participant;
            }
            
            m.quoted.message = extractMessageContent(m.msg?.contextInfo?.quotedMessage)
            m.quoted.type = getContentType(m.quoted.message) || Object.keys(m.quoted.message)[0]
            m.quoted.id = m.msg.contextInfo.stanzaId
            m.quoted.device = getDevice(m.quoted.id)
            m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
            
            m.quoted.isBot = m.quoted.id ? 
                ['HSK', 'BAE', 'B1E', '3EB0', 'B24E', 'WA'].some(a => m.quoted.id.startsWith(a) && [12, 16, 20, 22, 40].includes(m.quoted.id.length)) || 
                /(.)\1{5,}|[^a-zA-Z0-9]|[^0-9A-F]/.test(m.quoted.id) : false
            
            m.quoted.sender = alip.decodeJid(m.msg.contextInfo.participant)
            m.quoted.fromMe = m.quoted.sender === alip.decodeJid(alip.user.id)
            m.quoted.text = m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || m.quoted.description || ''
            m.quoted.msg = extractMessageContent(m.quoted.message[m.quoted.type]) || m.quoted.message[m.quoted.type]
            m.quoted.mentionedJid = m.quoted?.msg?.contextInfo?.mentionedJid || []
            
            m.quoted.body = m.quoted.msg?.text || 
                           m.quoted.msg?.caption || 
                           m.quoted?.message?.conversation || 
                           m.quoted.msg?.selectedButtonId || 
                           m.quoted.msg?.singleSelectReply?.selectedRowId || 
                           m.quoted.msg?.selectedId || 
                           m.quoted.msg?.contentText || 
                           m.quoted.msg?.selectedDisplayText || 
                           m.quoted.msg?.title || 
                           m.quoted?.msg?.name || 
                           m.quoted.msg?.description || 
                           ''

            m.getQuotedObj = async () => {
                if (!m.quoted.id) return false
                let q = await store.loadMessage(m.chat, m.quoted.id, alip)
                return await Serialize(alip, q, store)
            }
            
            m.quoted.key = {
                remoteJid: m.msg?.contextInfo?.remoteJid || m.chat,
                participant: m.quoted.sender,
                fromMe: areJidsSameUser(alip.decodeJid(m.msg?.contextInfo?.participant), alip.decodeJid(alip?.user?.id)),
                id: m.msg?.contextInfo?.stanzaId,
            }
            
            m.quoted.isGroup = m.quoted.chat.endsWith('@g.us')
            m.quoted.mentions = m.quoted.msg?.contextInfo?.mentionedJid || []
            
            m.quoted.prefix = /^[Â°â€¢Ï€Ă·Ă—Â¶âˆ†Â£Â¢â‚¬Â¥Â®â„¢+âœ“_=|~!?@#$%^&.Â©^]/gi.test(m.quoted.body) ? 
                             m.quoted.body.match(/^[Â°â€¢Ï€Ă·Ă—Â¶âˆ†Â£Â¢â‚¬Â¥Â®â„¢+âœ“_=|~!?@#$%^&.Â©^]/gi)[0] : 
                             /[\uD800-\uDBFF][\uDC00-\uDFFF]/gi.test(m.quoted.body) ? 
                             m.quoted.body.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/gi)[0] : ''

            m.quoted.command = m.quoted.body && m.quoted.body.replace(m.quoted.prefix, '').trim().split(/ +/).shift()
            m.quoted.isMedia = !!m.quoted.msg?.mimetype || !!m.quoted.msg?.thumbnailDirectPath || !!m.quoted.msg?.jpegThumbnail
            
            if (m.quoted.isMedia) {
                m.quoted.mime = m.quoted.msg?.mimetype
                m.quoted.size = m.quoted.msg?.fileLength
                m.quoted.height = m.quoted.msg?.height || ''
                m.quoted.width = m.quoted.msg?.width || ''
                if (/webp/i.test(m.quoted.mime)) {
                    m.quoted.isAnimated = m?.quoted?.msg?.isAnimated || false
                }
            }
            
            m.quoted.fakeObj = proto.WebMessageInfo.fromObject({
                key: {
                    remoteJid: m.quoted.chat,
                    fromMe: m.quoted.fromMe,
                    id: m.quoted.id,
                },
                message: m.quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {}),
            })
            
            m.quoted.download = () => alip.downloadMediaMessage(m.quoted)
            m.quoted.delete = () => {
                alip.sendMessage(m.quoted.chat, {
                    delete: {
                        remoteJid: m.quoted.chat,
                        fromMe: m.isBotAdmin ? false : true,
                        id: m.quoted.id,
                        participant: m.quoted.sender,
                    },
                })
            }
        }
    }

    m.download = () => alip.downloadMediaMessage(m)
    
    m.copy = () => Serialize(alip, proto.WebMessageInfo.fromObject(proto.WebMessageInfo.toObject(m)))
    
    m.react = (u) => alip.sendMessage(m.chat, { react: { text: u, key: m.key }})
    
    m.reply = async (content, options = {}) => {
        const { quoted = m, chat = m.chat, caption = '', ...validate } = options;
        
        if (typeof content === 'object') {
            return alip.sendMessage(chat, content, { ...options, quoted })
        } else if (typeof content === 'string') {
            try {
                if (/^https?:\/\//.test(content)) {
                    const data = await axios.get(content, { responseType: 'arraybuffer', timeout: 30000 });
                    const mime = data.headers['content-type'] || (await FileType.fromBuffer(data.data))?.mime
                    if (/gif|image|video|audio|pdf/i.test(mime)) {
                        return alip.sendFileUrl(chat, content, caption, quoted, options)
                    } else {
                        return alip.sendMessage(chat, { 
                            text: content, 
                            mentions: [...content.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), 
                            ...options 
                        }, { quoted })
                    }
                } else {
                    return alip.sendMessage(chat, { 
                        text: content, 
                        mentions: [...content.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), 
                        ...options 
                    }, { quoted })
                }
            } catch (e) {
                return alip.sendMessage(chat, { 
                    text: content, 
                    mentions: [...content.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), 
                    ...options 
                }, { quoted })
            }
        }
    }

    m.pushName = m.pushName || m.verifiedBizName || 'User'

    return m
}

module.exports = { LoadDatabase, MessagesUpset, SolvingHendler }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
});