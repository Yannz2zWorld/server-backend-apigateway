## Rules & Guidelines
1. Dilarang keras membagikan script secara cuma cuma.
2. Penjualan ( reseller only ) upgrade reseller ke **6381249703469**
5. Jangan menghapus credit yang ada di script.  
6. Permintaan fitur untuk update diperbolehkan, selama masuk akal.  
7. Bot akan selalu diperbarui dan dikembangkan secara berkala.

# RENAME SCRIP CUKUP BAGIAN ( SETTING.JS ) DILARANG KERAS BYPASS DB BOT/ATAU MENCOPOT SISTEM DB!!!

## Cara Menjalankan Script
1. Upload file ke panel hosting.  
2. Ekstrak (unarchive) file script.  
3. Pilih Node.js versi 23 atau lebih tinggi.  
4. Masukkan password pairing yang telah diberikan.  
5. Masukkan nomor bot.

## Cara pasang backup bot supaya database lama tidak hilang 
1. Upload sc versi terbaru, lalu unarchive
2. Upload file backup kalian, lalu unarchive
3. Restart.

© 2024-2025 @alifalfrl__

## New update v13.0.0

`new fitur`
___________
1. buy apk prem ( premku.com api, silakan daftar lalu generate apikey nya, profit bisa di settings di settings.js )

`fix fitur`
___________
1. perbaiki ptv, playtiktok, tanpa batasan size dan durasi
2. perbaikan play muskk, dan YouTube mp4
3. perbaikan spotify player 
4. fix auto ai menggunakan rich response, dan pemindahan auto ai ke message.js supaya lebih stabil dan bisa di gunakan 24/7 tanpa error connetion closed 
5. penambahan menu v8 location button ( tidak support private chat/iPhone )
6. fix ai edit, tofigure, dll
7. penambahan .tqto, di bagian .script bisa lu ubah di library/database/tqto.json kalo mau remake
8. fix fitur .buatlagu ( api covenant.sbs )
9. perubahan canvas .me, dan level up
10. totalchat menggunakan canvas & track real-time mesaage
11. getcase menggunakan rich response ( markdown javascript )
12. rich response label untuk .ping

13. sisanya gatau, gua lupa fix apa aja, sorry kalo ini banyak eror, gua bakal update lagi mungkin Minggu depan

___________
# disclaimer:
untuk fitur yang menggunakan api dari covenant, botcahx, termai, kemungkinan udah expired, kalo error berarti Expired, tunggu gua perpanjang nanti otomatis bisa di pake lagi

terutama di fitur .buatlagu, .artinama, kalo error itu tandanya apikeynya udah expired, botcahx, covenant, dan termai, secepatnya gua bakal perpanjang
___________


ydhlah segini aja dlu, next apdet baru fix fix lagi 😞

btw up reseller, pt, own bisa ke wa.me//6281249703469

`remove fitur`
___________

 * ©alipai Since 2024 - 2026
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
