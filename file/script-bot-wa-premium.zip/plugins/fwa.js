/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const axios = require('axios')
const { ImageUploadService } = require('node-upload-images')

async function uploadPixhost(buffer, filename = "file.jpg") {
    try {
        const service = new ImageUploadService('pixhost.to');
        const { directLink } = await service.uploadFromBinary(buffer, filename);
        return directLink;
    } catch (e) {
        console.error('Pixhost Upload Error:', e.message);
        return null;
    }
}

let handler = async (m, { alip, text, command, Reply }) => {
    if (!text) return Reply(`📌 *Contoh:* .${command} nama|bio|nomor\n\nContoh: .${command} Alip AI|Bot WhatsApp|6281249703469`)

    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!/image/.test(mime)) return Reply('❌ Reply gambar yang mau dijadikan fake profile!')

    const [nama, bio, nomor] = text.split('|').map(v => v.trim())
    if (!nama || !bio || !nomor) {
        return Reply('❌ Format salah! Gunakan: nama|bio|nomor')
    }

    await alip.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        const media = await q.download()
        if (!media) throw new Error('Gagal download gambar')

        const imageUrl = await uploadPixhost(media, 'image.jpg')
        if (!imageUrl) throw new Error('Gagal upload gambar')
        const apiUrl = `${global.apialip}/imagecreator/fakewa?apikey=${global.apikeyalip}&nama=${encodeURIComponent(nama)}&bio=${encodeURIComponent(bio)}&nomor=${encodeURIComponent(nomor)}&url=${encodeURIComponent(imageUrl)}`
        
        const response = await axios.get(apiUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000
        })

        await alip.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `✅ *Fake WhatsApp Profile*\n\n👤 Nama: ${nama}\n📝 Bio: ${bio}\n📱 Nomor: ${nomor}`
        }, { quoted: m })

        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (error) {
        console.error('[FAKEWA ERROR]', error)
        await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        Reply(`❌ Gagal: ${error.message}`)
    }
}

handler.command = ['fakewa', 'fwa', 'fakewhatsapp']

module.exports = handler