/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const fetch = require("node-fetch");

const DB_DIR = path.join(process.cwd(), "library/database");
const DB_USERS = path.join(DB_DIR, "panel_users.json");
const DB_PANELS = path.join(DB_DIR, "panel_panels.json");
const DB_NOTIF = path.join(DB_DIR, "panel_notif.json");

function ensureDB() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_USERS)) fs.writeFileSync(DB_USERS, "[]", "utf8");
  if (!fs.existsSync(DB_PANELS)) fs.writeFileSync(DB_PANELS, "[]", "utf8");
  if (!fs.existsSync(DB_NOTIF)) fs.writeFileSync(DB_NOTIF, "[]", "utf8");
}

function readJSON(file) {
  ensureDB();
  try {
    const raw = fs.readFileSync(file, "utf8");
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function writeJSON(file, data) {
  ensureDB();
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

function loadPanelDB() {
  return readJSON(DB_PANELS);
}

function savePanelDB(db) {
  writeJSON(DB_PANELS, db);
}

function loadUsersDB() {
  return readJSON(DB_USERS);
}

function saveUsersDB(db) {
  writeJSON(DB_USERS, db);
}

function loadNotifDB() {
  return readJSON(DB_NOTIF);
}

function saveNotifDB(db) {
  writeJSON(DB_NOTIF, db);
}

function upsertPanel(serverId, patch) {
  const db = loadPanelDB();
  const idx = db.findIndex((x) => String(x.serverId) === String(serverId));
  if (idx >= 0) db[idx] = { ...db[idx], ...patch, serverId: Number(serverId) || serverId };
  else db.push({ ...patch, serverId: Number(serverId) || serverId });
  savePanelDB(db);
  return db;
}

const fallbackPrefix = typeof global.prefix === "string" ? global.prefix : ".";

function normalizePhone(n) {
  n = String(n || "").replace(/\D/g, "");
  if (n.startsWith("0")) n = "62" + n.slice(1);
  if (!n.startsWith("62")) n = "62" + n;
  return n;
}

function toServerName(username) {
  let up = String(username || "").toUpperCase().trim();
  if (up.endsWith("STORE") && !up.includes(" ")) up = up.replace(/STORE$/, " STORE");
  return up;
}

const isResellerFn = typeof global.isReseller === "function" ? global.isReseller : () => false;
const DAY_MS = 24 * 60 * 60 * 1000;

function daysLeftFromExpiry(expiresAt) {
  const exp = Number(expiresAt || 0);
  if (!exp) return 0;
  return Math.ceil((exp - Date.now()) / DAY_MS);
}

function getApiHeaders() {
  return {
    "Authorization": `Bearer ${global.apikey}`,
    "Accept": "application/vnd.pterodactyl.v1+json",
    "Content-Type": "application/json"
  };
}

async function apiGET(endpoint) {
  const url = endpoint.startsWith("http") ? endpoint : `${global.domain}/api/application${endpoint}`;
  const res = await fetch(url, { method: "GET", headers: getApiHeaders() });
  return res;
}

async function apiPOST(endpoint, body = null) {
  const url = endpoint.startsWith("http") ? endpoint : `${global.domain}/api/application${endpoint}`;
  const options = { method: "POST", headers: getApiHeaders() };
  if (body) options.body = JSON.stringify(body);
  const res = await fetch(url, options);
  return res;
}

async function apiDELETE(endpoint) {
  const url = endpoint.startsWith("http") ? endpoint : `${global.domain}/api/application${endpoint}`;
  const res = await fetch(url, { method: "DELETE", headers: getApiHeaders() });
  return res;
}

async function apiPATCH(endpoint, body) {
  const url = endpoint.startsWith("http") ? endpoint : `${global.domain}/api/application${endpoint}`;
  const res = await fetch(url, { method: "PATCH", headers: getApiHeaders(), body: JSON.stringify(body) });
  return res;
}

async function suspendServer(serverId) {
  try {
    const res = await apiPOST(`/servers/${serverId}/suspend`);
    return res.ok;
  } catch {
    return false;
  }
}

async function unsuspendServer(serverId) {
  try {
    const res = await apiPOST(`/servers/${serverId}/unsuspend`);
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteServer(serverId) {
  try {
    const res = await apiDELETE(`/servers/${serverId}/force`);
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteUser(userId) {
  try {
    const res = await apiDELETE(`/users/${userId}`);
    return res.ok;
  } catch {
    return false;
  }
}

async function checkServerExists(serverId) {
  try {
    const res = await apiGET(`/servers/${serverId}`);
    return res.ok;
  } catch {
    return false;
  }
}

async function getServerAllocations(nodeId) {
  try {
    const res = await apiGET(`/nodes/${nodeId}/allocations`);
    if (!res.ok) return [];
    const data = await res.json();
    return data.data || [];
  } catch {
    return [];
  }
}

function getNotifState(serverId) {
  const db = loadNotifDB();
  const s = db.find((x) => String(x.serverId) === String(serverId));
  return { db, state: s || null };
}

function hasSent(serverId, key) {
  const { state } = getNotifState(serverId);
  if (!state) return false;
  const arr = Array.isArray(state.sent) ? state.sent : [];
  return arr.includes(String(key));
}

function markSent(serverId, key) {
  const { db, state } = getNotifState(serverId);
  const k = String(key);
  if (!state) {
    db.push({ serverId: Number(serverId) || serverId, sent: [k], updatedAt: Date.now() });
  } else {
    const sent = Array.isArray(state.sent) ? state.sent : [];
    if (!sent.includes(k)) sent.push(k);
    state.sent = sent;
    state.updatedAt = Date.now();
  }
  saveNotifDB(db);
}

function clearNotifState(serverId) {
  const db = loadNotifDB().filter((x) => String(x.serverId) !== String(serverId));
  saveNotifDB(db);
}

function buildReminderText({ daysLeft, serverName, serverId, mentionTag }) {
  if (daysLeft > 0) {
    const lines = [
      `Halo Kak ${mentionTag}, panel *${serverName}* kamu akan expired dalam waktu *${daysLeft} hari*.`,
      `Pastikan kamu segera melakukan perpanjangan ya agar data tetap aman.`,
      `Untuk renew, silakan gunakan perintah *${fallbackPrefix}renew ${serverId}* atau hubungi admin.`,
      `— ${global.botname || "Bot"}`,
    ];
    if (daysLeft === 7) lines[1] = `Waktu masih cukup, namun kami sarankan untuk segera memperpanjang.`;
    if (daysLeft === 5) lines[1] = `Masa aktif hampir habis, jangan sampai lupa ya.`;
    if (daysLeft === 3) lines[1] = `Hanya tersisa 3 hari. Segera renew untuk menghindari penangguhan.`;
    if (daysLeft === 1) lines[1] = `Peringatan terakhir: Panel kamu akan expired besok.`;
    return lines.join("\n");
  }

  return [
    `Pemberitahuan untuk Kak ${mentionTag},`,
    `Masa aktif panel *${serverName}* kamu telah *EXPIRED*.`,
    `Saat ini server telah di-suspend. Apabila ingin mengaktifkannya kembali, silakan lakukan perpanjangan.`,
    `Ketik: *${fallbackPrefix}renew ${serverId}* atau hubungi admin.`,
  ].join("\n");
}

async function checkAndSuspendExpiredServers(alip) {
  const panelDB = loadPanelDB();
  const now = Date.now();
  let updated = false;

  for (const p of panelDB) {
    if (!p.expiresAt) continue;
    
    const dLeft = daysLeftFromExpiry(p.expiresAt);
    
    if (dLeft <= 0 && !p.suspended) {
      const exists = await checkServerExists(p.serverId);
      if (exists) {
        const ok = await suspendServer(p.serverId);
        if (ok) {
          p.suspended = true;
          updated = true;
          
          const ownerPhone = normalizePhone(p.owner || "");
          if (ownerPhone) {
            try {
              const jid = `${ownerPhone}@s.whatsapp.net`;
              const mentionTag = `@${ownerPhone}`;
              const teks = buildReminderText({
                daysLeft: 0,
                serverName: p.name || "Unnamed",
                serverId: p.serverId,
                mentionTag,
              });
              await alip.sendMessage(jid, { text: teks, mentions: [jid] });
            } catch (e) {}
          }
        }
      }
    }
  }
  
  if (updated) savePanelDB(panelDB);
}

async function checkAndCleanupExpiredServers() {
  const panelDB = loadPanelDB();
  const now = Date.now();
  const CLEANUP_DAYS = 14;
  let updated = false;

  for (const p of panelDB) {
    if (!p.expiresAt) continue;
    
    const expiredSince = now - p.expiresAt;
    const expiredDays = Math.floor(expiredSince / DAY_MS);
    
    if (expiredDays > CLEANUP_DAYS && p.suspended) {
      const exists = await checkServerExists(p.serverId);
      if (exists) {
        const ok = await deleteServer(p.serverId);
        if (ok) {
          updated = true;
          clearNotifState(p.serverId);
        }
      } else {
        updated = true;
        clearNotifState(p.serverId);
      }
    }
  }
  
  if (updated) {
    const newDB = loadPanelDB().filter((p) => {
      if (!p.expiresAt) return true;
      const expiredSince = now - p.expiresAt;
      const expiredDays = Math.floor(expiredSince / DAY_MS);
      return expiredDays <= CLEANUP_DAYS || !p.suspended;
    });
    savePanelDB(newDB);
  }
}

let expirationInterval = null;
let cleanupInterval = null;

function startExpirationWatcher(alip) {
  if (expirationInterval) clearInterval(expirationInterval);
  if (cleanupInterval) clearInterval(cleanupInterval);
  
  expirationInterval = setInterval(() => {
    checkAndSuspendExpiredServers(alip).catch(console.error);
  }, 60 * 1000);
  
  cleanupInterval = setInterval(() => {
    checkAndCleanupExpiredServers().catch(console.error);
  }, 3600 * 1000);
}

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  const isReseller = isResellerFn(m.sender);
  const cmd = String(command || "").toLowerCase();

  const createCommands = ["1gb", "2gb", "3gb", "4gb", "5gb", "6gb", "7gb", "unlimited", "unli"];
  const specs = {
    "1gb": { ram: 1024, disk: 5120, cpu: 100 },
    "2gb": { ram: 2048, disk: 10240, cpu: 150 },
    "3gb": { ram: 3072, disk: 15360, cpu: 200 },
    "4gb": { ram: 4096, disk: 20480, cpu: 250 },
    "5gb": { ram: 5120, disk: 25600, cpu: 300 },
    "6gb": { ram: 6144, disk: 30720, cpu: 350 },
    "7gb": { ram: 7168, disk: 35840, cpu: 400 },
    unlimited: { ram: 0, disk: 51200, cpu: 0 },
    unli: { ram: 0, disk: 51200, cpu: 0 },
  };

  if (!global._expirationStarted && isCreator) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  if (createCommands.includes(cmd)) {
    if (!isCreator && !isReseller) {
      return Reply("Maaf, akses ditolak. Fitur ini hanya dapat digunakan oleh Reseller atau Owner.");
    }

    if (!text || !text.includes("|")) {
      return Reply(`Format salah. Contoh penggunaan:\n${fallbackPrefix}${cmd} username|628xxx|30`);
    }

    let [usernameRaw, nomorRaw, hariRaw] = text.split("|").map((v) => (v || "").trim());

    const username = String(usernameRaw || "").toLowerCase();
    const phone = normalizePhone(nomorRaw);
    const days = parseInt(hariRaw);

    if (isNaN(days) || days <= 0 || days > 365)
      return Reply("Durasi tidak valid. Silakan masukkan angka antara 1 hingga 365 hari.");
    if (!/^[a-z0-9]{3,15}$/.test(username))
      return Reply("Username tidak memenuhi syarat. Hanya diperbolehkan huruf kecil dan angka dengan panjang 3-15 karakter.");
    if (!phone || phone.length < 10) return Reply("Format nomor tujuan tidak valid.");

    const spec = specs[cmd];
    const ram = spec.ram;
    const disknya = spec.disk;
    const cpu = spec.cpu;

    try {
      await m.reply("Sedang memproses pembuatan panel. Mohon tunggu sebentar...");

      const allocations = await getServerAllocations(loc);
      let defaultAllocation = null;
      if (allocations.length > 0) {
        defaultAllocation = allocations[0].attributes.id;
      }

      const usersDB = loadUsersDB();
      let userEntry = usersDB.find((u) => String(u.phone) === String(phone));

      let panelUser;
      let password;

      if (!userEntry) {
        const email = `${username}@gmail.com`;
        const first_name = toServerName(username);
        password = username + crypto.randomBytes(2).toString("hex");

        const checkRes = await apiGET(`/users?filter[username]=${encodeURIComponent(username)}`);
        if (checkRes.ok) {
          const checkData = await checkRes.json();
          if (checkData?.data?.length > 0) {
            const u = checkData.data[0].attributes;
            return Reply(`Username ${u.username} telah digunakan oleh email ${u.email}. Silakan pilih username yang berbeda.`);
          }
        }

        const createUserRes = await apiPOST("/users", {
          email: email,
          username: username,
          first_name: first_name,
          last_name: "USER",
          password: password,
        });

        if (!createUserRes.ok) {
          const errorData = await createUserRes.json().catch(() => ({}));
          return Reply(`Pembuatan user gagal.\nDetail: ${JSON.stringify(errorData?.errors?.[0] || errorData)}`);
        }

        const createUserData = await createUserRes.json();
        panelUser = createUserData.attributes;

        userEntry = {
          phone: phone,
          userId: panelUser.id,
          username: panelUser.username,
          email: panelUser.email,
          password: password,
          createdAt: Date.now(),
        };

        usersDB.push(userEntry);
        saveUsersDB(usersDB);
      } else {
        panelUser = { id: userEntry.userId, username: userEntry.username, email: userEntry.email };
        password = userEntry.password;
      }

      const eggRes = await apiGET(`/nests/${nestid}/eggs/${egg}`);
      if (!eggRes.ok) {
        return Reply(`Pengambilan data egg gagal. Pastikan Egg ID (${egg}) dan Nest ID (${nestid}) benar.`);
      }
      const eggData = await eggRes.json();
      const startup_cmd = eggData.attributes.startup || "npm start";
      const docker_image = eggData.attributes.docker_image || "ghcr.io/parkervcp/yolks:nodejs_20";

      const serverName = toServerName(username);

      const createServerPayload = {
        name: serverName,
        description: `Server dibuat pada ${new Date().toLocaleDateString("id-ID")}`,
        user: panelUser.id,
        egg: parseInt(egg),
        docker_image: docker_image,
        startup: startup_cmd,
        environment: {
          INST: "npm install",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: ram === 0 ? null : ram,
          swap: 0,
          disk: disknya,
          io: 500,
          cpu: cpu === 0 ? null : cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 5
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      };

      if (defaultAllocation) {
        createServerPayload.allocation = { default: defaultAllocation };
      }

      const createServerRes = await apiPOST("/servers", createServerPayload);
      
      if (!createServerRes.ok) {
        const errorData = await createServerRes.json().catch(() => ({}));
        return Reply(`Pembuatan server gagal.\nDetail: ${JSON.stringify(errorData?.errors?.[0] || errorData)}`);
      }

      const createServerData = await createServerRes.json();
      const server = createServerData.attributes;
      const now = Date.now();
      const expiresAt = now + days * DAY_MS;

      upsertPanel(server.id, {
        serverId: server.id,
        name: server.name,
        owner: phone,
        username: panelUser.username,
        email: panelUser.email,
        reseller: isReseller ? m.sender : null,
        expiresAt: expiresAt,
        suspended: false,
        created: now,
        lastRenewed: now,
        notified: false,
        spec: { ram: ram, disk: disknya, cpu: cpu, type: cmd },
      });

      const expiryDate = new Date(expiresAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
      const ramDisplay = ram === 0 ? "Unlimited" : (ram / 1024).toFixed(1) + "GB";
      const diskDisplay = disknya === 0 ? "Unlimited" : (disknya / 1024).toFixed(1) + "GB";
      const cpuDisplay = cpu === 0 ? "Unlimited" : cpu + "%";

      const teks = `╭─⬣「 INFORMASI PANEL 」⬣
│
├─ Detail Akun
│  ├─ 👤 Username: ${panelUser.username}
│  ├─ 🔑 Password: ${password}
│  └─ 🌐 Halaman Login: ${global.domain}
│
├─ Spesifikasi Layanan
│  ├─ 💾 RAM: ${ramDisplay}
│  ├─ 💽 Disk: ${diskDisplay}
│  └─ ⚡ CPU: ${cpuDisplay}
│
├─ Detail Server
│  ├─ 🏷️ Nama: ${server.name}
│  ├─ 🆔 Server ID: ${server.id}
│  ├─ ⏰ Durasi Sewa: ${days} Hari
│  └─ 📅 Tanggal Expired: ${expiryDate}
│
╰─⬣

⚠️ Syarat & Ketentuan Berlaku:
- Dilarang menyebarkan atau menampilkan tautan panel kepada publik.
- Jika melakukan tangkapan layar, tautan panel wajib disensor.
- Harap menjaga kerahasiaan data panel Anda untuk menghindari penyalahgunaan.
- Garansi hanya diproses jika seluruh syarat dan ketentuan terpenuhi.
- Dilarang keras menggunakan layanan untuk aktivitas ilegal.`;

      const targetJid = `${phone}@s.whatsapp.net`;

      if (m.isGroup)
        await Reply("Panel berhasil dibuat. Data login telah dikirimkan ke nomor yang didaftarkan.");

      try {
        await alip.sendMessage(targetJid, { text: teks }, { quoted: m });
      } catch (e) {
        console.error("Gagal mengirim data login ke target:", e);
        await Reply(`Panel berhasil dibuat, namun pengiriman data login ke nomor ${phone} gagal.\nPastikan nomor tersebut telah terdaftar di WhatsApp.`);
      }

      return;
    } catch (err) {
      console.error("Kesalahan pembuatan panel:", err);
      return Reply(`Terjadi kesalahan sistem saat memproses panel.\n${err?.message || err}`);
    }
  }

  if (cmd === "delsrv") {
    if (!isCreator && !isReseller) {
      return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
    }
    const serverId = Number(String(text || "").trim());
    if (!serverId) return Reply(`Format penggunaan: ${fallbackPrefix}delsrv <ID Server>`);

    const db = loadPanelDB();
    const panel = db.find((p) => String(p.serverId) === String(serverId));

    if (panel && !isCreator && panel.reseller !== m.sender) {
      return Reply("Maaf, Anda tidak memiliki akses untuk menghapus server ini.");
    }

    await m.reply("Sedang memproses penghapusan server...");

    const exists = await checkServerExists(serverId);
    if (exists) {
      const ok = await deleteServer(serverId);
      if (!ok) return Reply("Penghapusan server gagal. Silakan periksa kembali konfigurasi API atau hak akses.");
    }

    const newDB = db.filter((p) => String(p.serverId) !== String(serverId));
    savePanelDB(newDB);
    clearNotifState(serverId);

    return Reply(`Server dengan ID ${serverId} beserta datanya berhasil dihapus.`);
  }

  if (cmd === "deluser") {
    if (!isCreator && !isReseller) {
      return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
    }

    if (!text) {
      return Reply(`Format penggunaan:\n${fallbackPrefix}deluser 628xxxx\natau\n${fallbackPrefix}deluser username`);
    }

    const key = String(text).trim().toLowerCase();
    const usersDB = loadUsersDB();
    const panelsDB = loadPanelDB();

    let userEntry = null;
    if (/^\d+$/.test(key)) {
      const phone = normalizePhone(key);
      userEntry = usersDB.find((u) => String(u.phone) === String(phone));
    } else {
      userEntry = usersDB.find((u) => String(u.username || "").toLowerCase() === key);
    }

    if (!userEntry) return Reply("Data pengguna tidak ditemukan.");

    const ownerPhone = String(userEntry.phone);
    const userServers = panelsDB.filter((p) => String(p.owner || "") === ownerPhone);

    if (!isCreator) {
      const ownedByReseller = userServers.some((p) => p.reseller === m.sender);
      if (!ownedByReseller) return Reply("Maaf, Anda tidak memiliki wewenang atas pengguna ini.");
    }

    await m.reply(`Sedang memproses penghapusan akun pengguna beserta ${userServers.length} server miliknya...`);

    let delOk = 0, delFail = 0;
    for (const s of userServers) {
      const sid = s.serverId;
      const exists = await checkServerExists(sid);
      if (exists) {
        const ok = await deleteServer(sid);
        if (ok) {
          delOk++;
          clearNotifState(sid);
        } else {
          delFail++;
        }
      } else {
        delOk++;
        clearNotifState(sid);
      }
    }

    const newPanels = panelsDB.filter((p) => String(p.owner || "") !== ownerPhone);
    savePanelDB(newPanels);

    const okUser = await deleteUser(userEntry.userId);

    const newUsers = usersDB.filter((u) => String(u.phone) !== String(ownerPhone));
    saveUsersDB(newUsers);

    return Reply(
      `Proses selesai.\n` +
      `Pengguna: ${userEntry.username} (${ownerPhone})\n` +
      `Server terhapus: ${delOk}\n` +
      `Server gagal dihapus: ${delFail}\n` +
      `Status penghapusan akun: ${okUser ? "Berhasil" : "Gagal"}`
    );
  }

  if (cmd === "notif") {
    if (!isCreator && !isReseller) {
      return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
    }

    const thresholds = [7, 5, 3, 1, 0];
    const panelDB = loadPanelDB();

    const targets = isCreator
      ? panelDB
      : panelDB.filter((p) => String(p.reseller || "") === String(m.sender));

    if (targets.length === 0) return Reply("Tidak ditemukan data panel terkait pada akun Anda.");

    await m.reply("Sedang memindai data dan mengirimkan pengingat...");

    let sentCount = 0;
    let suspendedCount = 0;

    for (const p of targets) {
      const serverId = p.serverId;
      const owner = normalizePhone(p.owner || "");
      if (!serverId || !owner) continue;

      const dLeft = daysLeftFromExpiry(p.expiresAt);

      let key = null;
      if (dLeft <= 0) key = 0;
      else if (thresholds.includes(dLeft)) key = dLeft;
      if (key === null) continue;

      if (hasSent(serverId, key)) continue;

      const jid = `${owner}@s.whatsapp.net`;
      const mentionTag = `@${owner}`;

      if (key === 0) {
        const exists = await checkServerExists(serverId);
        if (exists && !p.suspended) {
          const ok = await suspendServer(serverId);
          if (ok) {
            p.suspended = true;
            suspendedCount++;
          }
        } else if (!exists) {
          p.suspended = true;
        }
      }

      const teks = buildReminderText({
        daysLeft: dLeft <= 0 ? 0 : dLeft,
        serverName: p.name || "Unnamed",
        serverId: serverId,
        mentionTag: mentionTag,
      });

      try {
        await alip.sendMessage(jid, { text: teks, mentions: [jid] });
        markSent(serverId, key);
        sentCount++;
      } catch (e) {
        console.error("Gagal mengirim pengingat:", e);
      }
    }

    savePanelDB(panelDB);

    return Reply(`Proses pengingat selesai.\nPesan terkirim: ${sentCount}\nServer ditangguhkan otomatis: ${suspendedCount}`);
  }

  if (cmd === "listuser") {
    if (!isCreator && !isReseller) {
      return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
    }

    try {
      await m.reply("Sedang menghimpun data pengguna dan server...");

      const srvRes = await apiGET("/servers");
      if (!srvRes.ok) return Reply("Terjadi kendala saat mengambil data server.");
      const srvData = await srvRes.json();
      const servers = srvData.data || [];

      const usrRes = await apiGET("/users?per_page=200");
      if (!usrRes.ok) return Reply("Terjadi kendala saat mengambil data pengguna.");
      const usrData = await usrRes.json();
      const users = usrData.data || [];

      const usersDB = loadUsersDB();
      const panelDB = loadPanelDB();

      const countByUserId = {};
      for (const s of servers) {
        const uid = s?.attributes?.user;
        if (!uid) continue;
        countByUserId[uid] = (countByUserId[uid] || 0) + 1;
      }

      const allowedUserIdSet = new Set();
      if (!isCreator && isReseller) {
        for (const p of panelDB) {
          if (String(p.reseller || "") === String(m.sender)) {
            const phone = normalizePhone(p.owner || "");
            const u = usersDB.find((x) => String(x.phone) === String(phone));
            if (u?.userId) allowedUserIdSet.add(u.userId);
          }
        }
      }

      const admins = [];
      const normals = [];

      for (const u of users) {
        const a = u.attributes || {};
        const uid = a.id;

        if (!isCreator && isReseller) {
          if (!allowedUserIdSet.has(uid)) continue;
        }

        const isAdmin = !!a.root_admin || uid === 1;
        if (isAdmin) admins.push(u);
        else normals.push(u);
      }

      normals.sort((A, B) => {
        const aId = A.attributes?.id;
        const bId = B.attributes?.id;
        const aC = countByUserId[aId] || 0;
        const bC = countByUserId[bId] || 0;
        return bC - aC;
      });

      let out = `╭─⬣「 DAFTAR PENGGUNA 」⬣\n│\n`;

      if (isCreator && admins.length) {
        out += `├─ 👑 ADMIN PANEL\n`;
        let i = 0;
        for (const u of admins) {
          const a = u.attributes || {};
          const uid = a.id;
          const uname = a.username || "-";
          const email = a.email || "-";
          const total = countByUserId[uid] || 0;
          out += `│  ${++i}. ${uname}\n`;
          out += `│     ✉️ ${email}\n`;
          out += `│     🖥️ Jumlah Server: ${total}\n`;
        }
        out += `│\n`;
      }

      out += `├─ 👥 PENGGUNA LAYANAN\n`;
      if (!normals.length) {
        out += `│  (Tidak ada data)\n`;
      } else {
        let n = 0;
        for (const u of normals) {
          const a = u.attributes || {};
          const uid = a.id;
          const uname = a.username || "-";
          const email = a.email || "-";
          const total = countByUserId[uid] || 0;

          const local = usersDB.find((x) => String(x.userId) === String(uid));
          const phone = local?.phone ? `@${local.phone}` : "-";

          out += `│  ${++n}. ${uname} (${phone})\n`;
          out += `│     ✉️ ${email}\n`;
          out += `│     🖥️ Jumlah Server: ${total}\n`;
        }
      }

      out += `│\n╰─⬣`;
      return Reply(out);
    } catch (e) {
      console.error("ListUser Error:", e);
      return Reply("Pengambilan daftar pengguna gagal diproses.");
    }
  }

  if (cmd === "renew" || cmd === "renewserver") {
    try {
      if (!text) {
        const res = await apiGET("/servers");
        if (!res.ok) return Reply("Pengambilan data server gagal diproses.");

        const data = await res.json();
        const allPanels = loadPanelDB();

        const myServers = (data.data || []).filter((s) => {
          if (isCreator) return true;
          const panel = allPanels.find((p) => String(p.serverId) === String(s.attributes.id));
          return panel && panel.reseller === m.sender;
        });

        if (myServers.length === 0) return Reply("Tidak ditemukan server yang memenuhi syarat untuk diperpanjang.");

        let message = `🔄 SERVER TERSEDIA UNTUK PERPANJANGAN\n\n`;
        let n = 0;

        for (const s of myServers) {
          const serverId = s.attributes.id;
          const serverName = s.attributes.name;

          const panel = allPanels.find((p) => String(p.serverId) === String(serverId));
          const dLeft = panel ? daysLeftFromExpiry(panel.expiresAt) : 0;
          const status = panel
            ? dLeft > 0
              ? `🟢 (${dLeft} hari)`
              : `🔴 (Kadaluarsa${panel.suspended ? " / Ditangguhkan" : ""})`
            : `⚪ (Tidak ada data di database)`;

          message += `${++n}. ${serverName}\n`;
          message += `   🆔 ID Server: ${serverId}\n`;
          message += `   ⏰ Status: ${status}\n`;
          message += `   🔄 Perintah: ${fallbackPrefix}renew ${serverId}\n\n`;
        }

        return Reply(message);
      }

      const serverId = Number(String(text).trim());
      if (!serverId) return Reply(`Format salah. Gunakan: ${fallbackPrefix}renew <ID Server>`);

      const verifyRes = await apiGET(`/servers/${serverId}`);
      if (!verifyRes.ok) {
        if (verifyRes.status === 404) {
          const db = loadPanelDB();
          const newDB = db.filter((p) => String(p.serverId) !== String(serverId));
          savePanelDB(newDB);
          clearNotifState(serverId);
          return Reply(`ID Server ${serverId} tidak terdaftar. Database telah disesuaikan.`);
        }
        return Reply(`Verifikasi server gagal. Kode status: ${verifyRes.status}`);
      }

      const verifyData = await verifyRes.json();
      const server = verifyData.attributes;

      const db = loadPanelDB();
      const panel = db.find((p) => String(p.serverId) === String(serverId));

      if (!isCreator && (!panel || panel.reseller !== m.sender)) {
        return Reply(`Maaf, Anda tidak memiliki akses untuk memperpanjang server ${server.name}.`);
      }

      const days = 30;
      const now = Date.now();

      const oldExp = panel?.expiresAt ? Number(panel.expiresAt) : 0;
      const base = oldExp > now ? oldExp : now;
      const newExpiry = base + days * DAY_MS;

      upsertPanel(serverId, {
        expiresAt: newExpiry,
        lastRenewed: now,
        suspended: false,
        name: panel?.name || server?.name,
      });

      clearNotifState(serverId);

      await unsuspendServer(serverId).catch(() => {});

      const expiredDate = oldExp ? new Date(oldExp) : new Date(now);
      const newDate = new Date(newExpiry);

      const successText = `✅ PERPANJANGAN SERVER BERHASIL

🏷️ Nama Layanan: ${server.name}
🆔 ID Server: ${serverId}
➕ Penambahan Durasi: ${days} hari
📅 Masa Aktif Sebelumnya: ${expiredDate.toLocaleDateString("id-ID")}
📅 Masa Aktif Baru: ${newDate.toLocaleDateString("id-ID")}

Layanan Anda telah berhasil diperpanjang.`;

      return Reply(successText);
    } catch (error) {
      console.error("Renew Error:", error);
      return Reply(`Terjadi kendala sistem: ${error?.message || error}`);
    }
  }

  if (cmd === "mypanel") {
    try {
      const phone = normalizePhone(m.sender.split("@")[0]);
      const usersDB = loadUsersDB();
      const panelDB = loadPanelDB();

      const user = usersDB.find((u) => u.phone === phone);
      const myServers = panelDB.filter((p) => String(p.owner || "") === String(phone));

      if (!user || myServers.length === 0) return Reply("Anda saat ini belum memiliki layanan server yang aktif.");

      let suspendedNow = 0;
      for (const p of myServers) {
        const dLeft = daysLeftFromExpiry(p.expiresAt);
        if (dLeft <= 0 && !p.suspended && p.serverId) {
          const exists = await checkServerExists(p.serverId);
          if (exists) {
            const ok = await suspendServer(p.serverId);
            if (ok) {
              p.suspended = true;
              suspendedNow++;
            }
          } else {
            p.suspended = true;
            suspendedNow++;
          }
        }
      }
      savePanelDB(panelDB);

      let teks = `╭─⬣「 LAYANAN ANDA 」⬣\n│\n`;
      teks += `├─ 👤 Pengguna: ${user.username}\n`;
      teks += `├─ 📱 Kontak: ${phone}\n`;
      teks += `├─ 🖥️ Total Layanan: ${myServers.length}\n`;
      if (suspendedNow > 0) teks += `├─ 🧷 Ditangguhkan otomatis: ${suspendedNow} (Kadaluarsa)\n`;
      teks += `│\n`;
      teks += `├─ Daftar Layanan Aktif:\n`;

      let i = 0;
      for (const p of myServers) {
        const dLeft = daysLeftFromExpiry(p.expiresAt);
        const status = dLeft > 0 ? `🟢 ${dLeft} hari` : `🔴 Kadaluarsa${p.suspended ? " / Ditangguhkan" : ""}`;
        const expDate = p.expiresAt ? new Date(Number(p.expiresAt)).toLocaleDateString("id-ID") : "-";
        teks += `│  ${++i}. ${p.name || "Tanpa Nama"} — ${status} (Hingga: ${expDate})\n`;
      }

      teks += `│\n╰─⬣\n\n🔒 Catatan: Data login dirahasiakan untuk menjaga keamanan akun Anda.`;
      return Reply(teks);
    } catch (e) {
      console.error("MyPanel Error:", e);
      return Reply("Pengambilan informasi layanan gagal diproses.");
    }
  }

  if (cmd === "listpanel") {
    try {
      await m.reply("Sedang memuat data operasional server...");

      const res = await apiGET("/servers");
      if (!res.ok) return Reply(`Sinkronisasi data dengan server utama gagal (Kode: ${res.status}).`);

      const data = await res.json();
      if (!data.data || data.data.length === 0) return Reply("Tidak ditemukan riwayat layanan yang sedang berjalan.");

      const allPanels = loadPanelDB();

      const filtered = !isCreator && isReseller
        ? data.data.filter((s) => {
            const p = allPanels.find((x) => String(x.serverId) === String(s.attributes.id));
            return p && p.reseller === m.sender;
          })
        : data.data;

      if (filtered.length === 0) return Reply("Anda belum memiliki server yang terdaftar di bawah pengawasan Anda.");

      let listText = `╭─⬣「 REKAPITULASI SERVER 」⬣\n│\n`;
      let serverCount = 0, activeInDB = 0, expiredInDB = 0;

      for (const s of filtered) {
        const serverId = s.attributes.id;
        const serverName = s.attributes.name;
        const serverUser = s.attributes.user;

        const panelInfo = allPanels.find((p) => String(p.serverId) === String(serverId));
        const dLeft = panelInfo ? daysLeftFromExpiry(panelInfo.expiresAt) : 0;
        const status = panelInfo ? (dLeft > 0 ? "🟢" : "🔴") : "⚪";

        listText += `├─ ${++serverCount}. ${serverName}\n`;
        listText += `│  ├─ 🆔 ID Server: ${serverId}\n`;
        listText += `│  ├─ 👤 ID Pengguna: ${serverUser}\n`;

        if (panelInfo) {
          listText += `│  ├─ 👤 Pemilik: ${panelInfo.owner || "-"}\n`;
          listText += `│  ├─ 📅 Batas Waktu: ${panelInfo.expiresAt ? new Date(Number(panelInfo.expiresAt)).toLocaleDateString("id-ID") : "-"}\n`;
          listText += `│  └─ 🔋 Status Saat Ini: ${status} (${dLeft} hari)${panelInfo.suspended ? " / Ditangguhkan" : ""}\n`;
          if (dLeft > 0) activeInDB++;
          else expiredInDB++;
        } else {
          listText += `│  └─ ⚠️ Data tidak tersinkronisasi dengan database lokal\n`;
        }
      }

      const notInServer = allPanels.filter((p) => !(data.data || []).some((s) => String(s.attributes.id) === String(p.serverId))).length;

      listText += `│\n├─ Ringkasan Sistem\n`;
      listText += `│  ├─ 🖥️ Total Ditampilkan: ${serverCount}\n`;
      listText += `│  ├─ ✅ Layanan Aktif: ${activeInDB}\n`;
      listText += `│  ├─ 🔴 Layanan Kadaluarsa: ${expiredInDB}\n`;
      listText += `│  └─ 🗑️ Anomali Data: ${notInServer}\n`;
      listText += `╰─⬣`;

      return Reply(listText);
    } catch (e) {
      console.error("ListPanel Error:", e);
      return Reply("Pengambilan rekapitulasi server gagal dilakukan.");
    }
  }
};

handler.command = [
  "1gb", "2gb", "3gb", "4gb", "5gb", "6gb", "7gb",
  "unlimited", "unli", "mypanel", "listpanel",
  "renew", "renewserver", "delsrv", "deluser", "notif", "listuser"
];

module.exports = handler;